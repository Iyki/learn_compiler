int main(){
 	int a;
	int b;
	a = 10;
	b = a + 20;
	
	return 0; 
}
