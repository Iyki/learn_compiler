int func(){
 	int a;
	
	if (a < 10) { 
		int b;
		b = 20;
		return (b + a);
	}
	return 0; 
}
